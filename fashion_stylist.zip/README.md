# Fashion-Stylist-Mod
This is a player decoration mod.

This mod will define a bunch of hair dye, and an NPC.

In the `/modules` folder you will see define and scripts files we are loading in the main `mod` file
In the `/sprites` folder you will see an example of various sprites used in `api_define_*()` calls
